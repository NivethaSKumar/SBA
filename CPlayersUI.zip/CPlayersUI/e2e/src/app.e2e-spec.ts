import { AppPage } from './app.po';
import { browser, by,logging } from 'protractor';

describe('workspace-project App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });


  it('should display welcome message', () => {
    page.navigateTo();
    expect(browser.getTitle()).toEqual('CPlayersUI');
  });

  it('should be able to navigate to register page', () => {
    browser.element(by.id('onSignUp')).click();
    expect(browser.getCurrentUrl()).toContain('/register');
    browser.driver.sleep(1000);
  });

  it('should be able to register user with Valid fields', () => {
    browser.element(by.id('username')).sendKeys('Admin');
    browser.driver.sleep(500);
    browser.element(by.id('password')).sendKeys('admin');
    browser.driver.sleep(500);
    browser.element(by.id('confirmpassword')).sendKeys('admin');
    browser.driver.sleep(500);
    browser.element(by.id('email')).sendKeys('ad@gmail.com');
    browser.driver.sleep(500);
    browser.element(by.id('btnregister')).click();
    expect(browser.getCurrentUrl()).toContain('/login');
    browser.driver.sleep(1000);
  });

  it('should be able to login user with Valid Credentials', () => {
    browser.element(by.id('userName')).sendKeys('Admins');
    browser.driver.sleep(500);
    browser.element(by.id('password')).sendKeys('pwd');
    browser.driver.sleep(500);
    browser.element(by.id('btnSubmit')).click();
    expect(browser.getCurrentUrl()).toContain('/findplayer');
    browser.driver.sleep(1000);
  });

  it('should be able to fetch player details', () => {
    browser.element(by.id('playerName')).sendKeys('Sachin Rana');
    browser.driver.sleep(500);
    browser.element(by.id('btnSearch')).click();
    expect(browser.getCurrentUrl()).toContain('/findplayer');
    browser.driver.sleep(1000);
  });

  it('should be able to navigate to Player Statistics page', () => {
    browser.driver.sleep(1000);
    browser.element(by.className('glyphicon glyphicon-th-large')).click();
    browser.driver.sleep(2000);
    expect(browser.getCurrentUrl()).toContain('/statistics');
  });

  it('should be able to fetch player statistics', () => {
    browser.element(by.id('playerId')).sendKeys('33757');
    browser.driver.sleep(500);
    browser.element(by.id('btnSearch')).click();
    expect(browser.getCurrentUrl()).toContain('/statistics');
    browser.driver.sleep(1000);
  });
  
  
  it('should be able to navigate to Favourites page', () => {
    browser.driver.sleep(1000);
    browser.element(by.className('glyphicon glyphicon-list-alt')).click();
    browser.driver.sleep(2000);
    expect(browser.getCurrentUrl()).toContain('/favourites');
  });

  it('should be able to logout and navigate to login page', () => {
    browser.driver.sleep(1000);
    browser.element(by.className('glyphicon glyphicon-log-out')).click();
    browser.driver.sleep(2000);
    expect(browser.getCurrentUrl()).toContain('/login');
  });


 
});
