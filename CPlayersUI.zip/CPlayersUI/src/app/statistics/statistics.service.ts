import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import { map } from "rxjs/operators";


@Injectable({
  providedIn: 'root'
})
export class StatisticsService {
 
  constructor(private http:HttpClient) {}
  public getPlayerStatistics(postData):Observable<any>{
    console.log(postData);
  const findPlayerUrl='http://cricapi.com/api/playerStats?apikey=K9TUU2yotFgbyVMlvjaQNgBPQyC2&pid='+postData['playerId'];
    return this.http.get(findPlayerUrl);

  }
  }

  
