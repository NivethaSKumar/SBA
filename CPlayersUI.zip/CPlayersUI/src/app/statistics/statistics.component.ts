import { Component, OnInit } from '@angular/core';
import{StatisticsService} from './statistics.service';
import {AuthService} from '../interceptors/auth.service';
import { Router } from '@angular/router';
import {playerModel} from './model/playerstats.model';

@Component({
  selector: 'app-books',
  templateUrl: './statistics.component.html',
  styleUrls: ['./statistics.component.css']
})
export class StatisticsComponent implements OnInit {
  public playerModel: playerModel;
  public playerList:any;
  public rowData:any=[];
  public rowData1:any=[];
  public rowData2:any=[];
  public rowData3:any=[];
  public list:any;
  constructor(private findPlayerService:StatisticsService,private authService:AuthService,private router:Router) { }
  
  columnDefs = [
    {headerName: '10', field: '10',width:65,minWidth:50},
    {headerName: '5w', field: '5w',width:65,minWidth:50 },
    {headerName: 'SR', field: 'SR',width:65,minWidth:50},
    {headerName: 'Econ', field: 'Econ',width:68,minWidth:50},
    {headerName: 'Ave', field: 'Ave',width:75,minWidth:50},
    {headerName: 'BBM', field: 'BBM',width:70,minWidth:50},
    {headerName: 'BBI', field: 'BBI',width:68,minWidth:50},
    {headerName: 'Wkts', field: 'Wkts',width:68,minWidth:50},
    {headerName: 'Runs', field: 'Runs',width:68,minWidth:50},
    {headerName: 'Balls', field: 'Balls',width:68,minWidth:50},
    {headerName: 'Inns', field: 'Inns',width:68,minWidth:50},
    {headerName: 'Mat', field: 'Mat',width:65,minWidth:50}
];
columnDefs1 = [
  {headerName: '50', field: '50',width:65,minWidth:50},
  {headerName: '100', field: '100',width:65,minWidth:50 },
  {headerName: 'St', field: 'St',width:65,minWidth:50},
  {headerName: 'Ct', field: 'Ct',width:68,minWidth:50},
  {headerName: '6s', field: '6s',width:68,minWidth:50},
  {headerName: '4s', field: '4s',width:70,minWidth:50},
  {headerName: 'SR', field: 'SR',width:75,minWidth:50},
  {headerName: 'BF', field: 'BF',width:68,minWidth:50},
  {headerName: 'Ave', field: 'Ave',width:75,minWidth:50},
  {headerName: 'HS', field: 'HS',width:68,minWidth:50},
  {headerName: 'Runs', field: 'Runs',width:68,minWidth:50},
  {headerName: 'NO', field: 'NO',width:65,minWidth:50},
  {headerName: 'Inns', field: 'Inns',width:68,minWidth:50},
  {headerName: 'Mat', field: 'Mat',width:65,minWidth:50}
];
  ngOnInit() {
    this.playerModel=new playerModel();
    }
    public logout(){
      localStorage.clear;
      this.authService.setBearerToken('');
      this.router.navigate(['login']);
    }

    public fetchPlayerStatistics(){

      if((this.playerModel.playerId===undefined || this.playerModel.playerId.length===0) ){
          alert('Please enter the playerId');
          return;
      }
  
        if((this.playerModel.playerId!==undefined && this.playerModel.playerId.length!==0 )){
      const secret = this.authService.getBearerToken();
      this.authService.setBearerToken("openAPI");
  
      const postData={
        
        'playerId': this.playerModel.playerId?this.playerModel.playerId:''
      }
      this.findPlayerService.getPlayerStatistics(postData).subscribe(res=>{  
        this.list=res;
        console.log('PlayerData',res);
      this.playerList=this.list; 
      this.rowData.push(this.playerList.data.bowling.listA);
      this.rowData1.push(this.playerList.data.bowling.firstClass);
      this.rowData2.push(this.playerList.data.batting.listA);
      this.rowData3.push(this.playerList.data.batting.firstClass)
      console.log('RowData',this.rowData);
      if(this.playerList===undefined || this.playerList.length===0 ){
            
        alert('No Results Found for the searched item');
        return;
      }
      this.authService.setBearerToken(secret);
        console.log('list',this.playerList);
  
          } )
        }
       
    }
    
  }

  
