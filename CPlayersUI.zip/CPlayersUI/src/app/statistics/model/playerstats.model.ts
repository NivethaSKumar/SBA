export class booksModel {
    public bookname: string;
    public authorname: string;
    public genre: string;
    constructor(){
        this.bookname='';
        this.authorname='';
    }
}
export class UserModel {
    public userName: string;
    public password: string;
}

export class playerModel{
    public playerId: string;
    constructor(){
        this.playerId='';
    }
}