import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import{StatisticsService} from './statistics.service';
import {AuthService} from '../interceptors/auth.service';
import { Router ,ActivatedRoute} from '@angular/router';
import { StatisticsComponent } from './statistics.component';
import { FormsModule } from '@angular/forms'; 
import { of } from "rxjs";
import { RouterTestingModule } from "@angular/router/testing";
import { HttpClient,HttpHandler } from '@angular/common/http';
import { AgGridModule } from 'ag-grid-angular';
let mockGetPlayerStatistics={
  getPlayerStatistics:(data)=>{
    return of (
      {
      "pid": 33757,
	"country": "India",
	"battingStyle": "Right-hand bat",
	"bowlingStyle": "Right-arm medium-fast",
	"currentAge": "33 years 40 days",
	"born": "September 18, 1984, Gurgaon, Haryana",
	"fullName": "Sachin Rana",
	"name": "Sachin Rana",
	"data": {
		"bowling": {
			"listA": {
				"10": "0",
				"5w": "0",
				"4w": "1",
				"SR": "48.1",
				"Econ": "4.55",
				"Ave": "36.59",
				"BBM": "4/37",
				"BBI": "4/37",
				"Wkts": "42",
				"Runs": "1537",
				"Balls": "2023",
				"Inns": "",
				"Mat": "56"
			},
			"firstClass": {
				"10": "0",
				"5w": "5",
				"4w": "6",
				"SR": "58.0",
				"Econ": "2.62",
				"Ave": "25.34",
				"BBM": "",
				"BBI": "5/32",
				"Wkts": "142",
				"Runs": "3599",
				"Balls": "8239",
				"Inns": "",
				"Mat": "73"
			}
		},
		"batting": {
			"listA": {
				"50": "6",
				"100": "1",
				"St": "0",
				"Ct": "21",
				"6s": "",
				"4s": "",
				"SR": "73.36",
				"BF": "1851",
				"Ave": "29.52",
				"HS": "110",
				"Runs": "1358",
				"NO": "7",
				"Inns": "53",
				"Mat": "56"
			},
			"firstClass": {
				"50": "15",
				"100": "7",
				"St": "0",
				"Ct": "91",
				"6s": "",
				"4s": "",
				"SR": "49.33",
				"BF": "7433",
				"Ave": "30.81",
				"HS": "163*",
				"Runs": "3667",
				"NO": "6",
				"Inns": "125",
				"Mat": "73"
			}
		}
	},
	"ttl": 2,
	"provider": {
		"source": "Various",
		"url": "https://cricapi.com/",
		"pubDate": "2020-07-20T10:56:39.578Z"
	},
  "creditsLeft": 250
}
    )
  }
};
let router = {
  navigate: jasmine.createSpy("navigate")
};
let mockAuthService={
  setBearerToken:()=>{
    return of("Bearer openAPI")
  }
};
describe('StatisticsComponent', () => {
  let component: StatisticsComponent;
  let fixture: ComponentFixture<StatisticsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StatisticsComponent ],
      imports: [RouterTestingModule.withRoutes([]), FormsModule, AgGridModule],
      providers: [
        { provide: StatisticsService, useValue: mockGetPlayerStatistics},
        { provide: AuthService, useValue: mockAuthService},
        { provide: Router, useValue: router },
        {
          provide: ActivatedRoute,
          useValue: {
            params: of({ playername: 'Sachin Rana' }),
           //fragment: of({ fragment: "matches" }),
          },
        },
        HttpClient,
        HttpHandler,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StatisticsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
	});
	
	it('should have "playerId" field', async(() => {
    fixture.whenStable().then(() => {
      let playerId = component.playerModel.playerId;
      playerId="33575";
      expect(playerId!==undefined).toBeTruthy();
    });
  }));

  it("should be able to successfully fetch Player Statistics", async(() => {
    fixture.whenStable().then(() => {
      let playerId = component.playerModel.playerId;
		 playerId="33575";
		 component.fetchPlayerStatistics();
    });
	}));
});
