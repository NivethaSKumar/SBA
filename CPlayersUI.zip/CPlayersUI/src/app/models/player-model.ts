export class playerModel{
    public playerId:string;
    public playersName:string;
    public country : string;

}
export class UserModel {
    public userName: string;
    public password: string;
}