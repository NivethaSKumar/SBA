import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AgGridModule } from 'ag-grid-angular';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule,HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule } from '@angular/forms'; 
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import {StatisticsComponent} from './statistics/statistics.component';
import{FavouritesComponent} from './favourites/favourites.component';
import {AuthService} from './interceptors/auth.service'
import {LoginService} from '../app/login/login.service'
import {RegisterService} from '../app/register/register.service'
import {FindPlayerService} from '../app/findplayer/findplayer.service'
import{AuthInterceptor} from '../app/interceptors/auth.interceptor'
import{FindPlayerComponent} from './findplayer/findplayer.component'
import{StatisticsService} from '../app/statistics/statistics.service'
import{FavouritesService} from '../app/favourites/favourites.service'



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    FindPlayerComponent,
    StatisticsComponent,
    FavouritesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule ,
    FormsModule,
    AgGridModule
  ],
  providers: [AuthService,AppRoutingModule,{
    provide: HTTP_INTERCEPTORS,
    useClass: AuthInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
