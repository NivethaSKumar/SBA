import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import { map } from "rxjs/operators";


@Injectable({
  providedIn: 'root'
})
export class FindPlayerService {
  constructor(private http:HttpClient) {}
  public getPlayerDtls(postData):Observable<any>{
    console.log(postData);
  const findPlayerUrl='http://cricapi.com/api/playerFinder?apikey=K9TUU2yotFgbyVMlvjaQNgBPQyC2&name='+postData['playername'];
    return this.http.get(findPlayerUrl);

  }
  public addFavPlayer(postData):Observable<any>{
    const playerUrl='http://localhost:8051/info/players/add-players'+ '/'+ localStorage.getItem('userName')
     return this.http.post(playerUrl,postData).pipe(map(
       (data: any) => {
         console.log(data);
         return data;
       },
       (error: any) => {
         console.log(error);
         return error;
       }));;
 
   }
   public removeFavPlayer(postData):Observable<any>{
    const playerUrl='http://localhost:8051/info/players/rmv-players'+ '/'+ localStorage.getItem('userName')
     return this.http.post(playerUrl,postData).pipe(map(
       (data: any) => {
         console.log(data);
         return data;
       },
       (error: any) => {
         console.log(error);
         return error;
       }));;
 
   }
  }

  
