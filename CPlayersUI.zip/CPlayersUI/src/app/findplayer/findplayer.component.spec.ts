import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FindPlayerComponent } from './findplayer.component';
import { of } from "rxjs";
import { RouterTestingModule } from "@angular/router/testing";
import {AuthService} from '../interceptors/auth.service';
import { Router,ActivatedRoute } from '@angular/router';
import { HttpClient,HttpHandler } from '@angular/common/http';
import { FormsModule } from '@angular/forms'; 
import {FindPlayerService} from './findplayer.service';


let mockFindPlayerDtls={
  getPlayerDtls:(data)=>{
    return of (
      {"data": [{
        "pid": 33757,
        "fullName": "Sachin Rana",
        "name": "Sachin Rana"
      }]
      }
    )
  }
};
let mockAddPlayer={
  addPlayer:(data)=>{
    return of ('Favourite Player Details added to your system')
  }
};
let mockRemovePlayer={
  addPlayer:(data)=>{
    return of ('Favourite Player details removed from the system')
  }
};
let router = {
  navigate: jasmine.createSpy("navigate")
};

let mockAuthService={
  isUserAuthenticate:(userInfo)=>{
    if(userInfo.username==="Admins" && userInfo.password==="password"){
      return of (true)
    }
  }
};
describe('FindPlayerComponent', () => {
  let component: FindPlayerComponent;
  let fixture: ComponentFixture<FindPlayerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FindPlayerComponent ],
      imports: [RouterTestingModule.withRoutes([]), FormsModule],
      providers: [
        { provide: AuthService, useValue: mockAuthService },
        { provide: FindPlayerService, useValue: mockFindPlayerDtls },
        { provide: FindPlayerService, useValue: mockAddPlayer },
        { provide: FindPlayerService, useValue: mockRemovePlayer },
        { provide: Router, useValue: router },
        {
          provide: ActivatedRoute,
          useValue: {
            params: of({ playername: 'Sachin Rana' }),
          },
        },
        HttpClient,
        HttpHandler,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FindPlayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have "playername" field', async(() => {
    fixture.whenStable().then(() => {
      let playername = component.playerModel.playername;
      playername="Sachin Rana";
      expect(playername!==undefined).toBeTruthy();
    });
  }));

  it("should be able to fetch Player Details", async(() => {
    fixture.whenStable().then(() => {
      let playername = component.playerModel.playername;
      playername="Sachin Rana";
		 component.fetchPlayerDtls();
    });
  }));
});
