export class UserModel {
    public userName: string;
    public password: string;
}

export class playerModel{
    public playername: string;
    constructor(){
        this.playername='';
    }
}
export class addModel{
    public playerId:string;
    public playersName:string;
    public country : string;
    public isAdded?:boolean;

}