import { Component, OnInit } from '@angular/core';
import {FindPlayerService} from './findplayer.service';
import { Router } from '@angular/router';
import {playerModel,addModel} from './model/player.model';
import {AuthService} from '../interceptors/auth.service';

@Component({
  selector: 'app-books',
  templateUrl: './findplayer.component.html',
  styleUrls: ['./findplayer.component.css']
})
export class FindPlayerComponent implements OnInit {
  public playerModel: playerModel;
  public addModel:addModel;
  public playerList:any=[];
  public list=[];
  constructor(private findPlayerService:FindPlayerService,private authService:AuthService,private router:Router) { }
  ngOnInit() {
    this.playerModel=new playerModel();
    }

    public fetchPlayerDtls(){

      if((this.playerModel.playername===undefined || this.playerModel.playername.length===0 ) ){
          alert('Please enter the playername');
          return;
      }
  
        if((this.playerModel.playername!==undefined && this.playerModel.playername.length!==0 )){
     const secret = this.authService.getBearerToken();
    this.authService.setBearerToken("openAPI");
  
      const postData={
        
        'playername': this.playerModel.playername?this.playerModel.playername:''
      }
      this.findPlayerService.getPlayerDtls(postData).subscribe(res=>{  
        this.list=res.data;
        console.log('PlayerData',res.data);
      this.playerList=this.list; 
      if(this.playerList===undefined || this.playerList.length===0 ){
            
        alert('No Results Found for the searched item');
        return;
      }
      this.playerList.forEach((x) =>{
        x.isAdded=false;
      })
      this.authService.setBearerToken(secret);
        console.log('list',this.playerList);
  
          } )
        }
       
    }


    public addPlayer(data,index){
      this.playerList[index].isAdded=!this.playerList[index].isAdded;
      const postData={
        'username': localStorage.getItem('userName') ? localStorage.getItem('userName') : '',
        'password': localStorage.getItem('password') ? localStorage.getItem('password') : ''
      }
      this.authService.isUserAuthenticate(postData).subscribe(res => {
        if(res == true) {
          console.log(data['pid']);
          console.log(data['fullName']);
          console.log(data['name']);
          let a=data['pid'];
          let b=data['fullName'];
          let c=data['name']
          const postData={
            'playerId': a?a:'',
            'playersName': b?b:'',
            'country': c?c:''
          }
      this.findPlayerService.addFavPlayer(postData).subscribe(res => {
        if(res['response']==='Favourite Player Details added to your system') {
          
          alert('Favourite Player Details added to your system');
        }else if(res['response']==='Player Details already available in favourite list'){
          alert('Player Details already available in favourite list');
        }
      })
    
    }
  })
    }
    public removePlayer(data,index){
      this.playerList[index].isAdded=!this.playerList[index].isAdded;
      const postData={
        'username': localStorage.getItem('userName') ? localStorage.getItem('userName') : '',
        'password': localStorage.getItem('password') ? localStorage.getItem('password') : ''
      }
      this.authService.isUserAuthenticate(postData).subscribe(res => {
        if(res == true) {
          console.log(data['pid']);
          console.log(data['fullName']);
          console.log(data['name']);
          let a=data['pid'];
          let b=data['fullName'];
          let c=data['name'];
          const postData={
            'playerId': a?a:'',
            'playersName': b?b:'',
            'country': c?c:''
          }
      this.findPlayerService.removeFavPlayer(postData).subscribe(res => {
        if(res['response']==='Favourite Player details removed from the system') {
          
          alert('Favourite Player details removed from the system');
        }else {
          alert('Favourite Player Details could not be removed from the system! Try removing again');
        }


      })
     
    }
  })
    }

    public logout(){
      localStorage.clear;
      this.authService.setBearerToken('');
      this.router.navigate(['login']);
    }
    
  }

  
