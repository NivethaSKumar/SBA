import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from "rxjs/operators";


@Injectable()
export class AuthService {
 private authUri = 'http://localhost:8050/login/players/login';
private registerUri='http://localhost:8050/login/players/register';
  
  constructor(public http: HttpClient) {

  }

  authenticateUser(data) {
    return this.http.post<any>(this.authUri, data);
  }

  registerUser(data) {
    return this.http.post<any>(this.registerUri, data);
  }

  setBearerToken(token) {
    localStorage.setItem('bearerToken', token);
  }

  getBearerToken() {
   return localStorage.getItem('bearerToken');
  }

  isUserAuthenticated(jwtRequest):  Observable<boolean> {
          return this.http.post('http://localhost:8050/login/authenticate', jwtRequest,
           {}).pipe(map((data: any) => {
           // console.log(data);
            let token = data['token'];
            if(token === null) {
                return false;
            }
            this.setBearerToken(token);
            return true;
          },
          (error: any) => {
            console.log(error);
            return false;
          }));
        }

        isUserAuthenticate(jwtRequest):  Observable<boolean> {
          return this.http.post('http://localhost:8051/info/authenticate', jwtRequest,
           {}).pipe(map((data: any) => {
            //console.log(data);
            let token = data['token'];
            if(token === null) {
                return false;
            }
            this.setBearerToken(token);
            return true;
          },
          (error: any) => {
            console.log(error);
            return false;
          }));
        }
           
         


}
