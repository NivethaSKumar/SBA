import { Injectable } from '@angular/core';
import {
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor
} from '@angular/common/http';

import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';


@Injectable()
export class AuthInterceptor implements HttpInterceptor {

    constructor(private authService: AuthService) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
            let modified:any ;
            if((this.authService.getBearerToken()!=null) && (this.authService.getBearerToken()!="openAPI")){
            modified= req.clone({
                setHeaders:
                {
                    'Authorization': `Bearer ${this.authService.getBearerToken()}`, "Accept": "application/json",
                    "content-type": "application/json"
                }
            });
        }else{
            modified= req.clone({
                setHeaders:
                {
                   
                }
            });
        }
            return next.handle(modified);
        }
       
}

