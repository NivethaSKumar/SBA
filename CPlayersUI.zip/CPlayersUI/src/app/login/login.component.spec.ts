import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginComponent } from './login.component';
import { of } from "rxjs";
import { RouterTestingModule } from "@angular/router/testing";
import { Router } from '@angular/router';
import { HttpClient,HttpHandler } from '@angular/common/http';
import { FormsModule } from '@angular/forms'; 
import {LoginService} from './login.service'
import {AuthService} from '../interceptors/auth.service';
import { userInfo } from 'os';
import { UserModel, User } from 'src/app/login/models/login-model';

let router = {
  navigate: jasmine.createSpy("navigate")
};
let mockAuthService={
  isUserAuthenticated:(userInfo)=>{
    if(userInfo.username==="Admins" && userInfo.password==="password"){
      return of (true)
    }
  }
}

let mockLoginService={
  getLogin:(data)=>{
    return of ('Valid User. Login successful')
  }
}
describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginComponent ],
      imports: [RouterTestingModule.withRoutes([]), FormsModule],
      providers: [
        { provide: AuthService, useValue: mockAuthService },
        { provide: LoginService, useValue: mockLoginService },
        { provide: Router, useValue: router },
        HttpClient,
        HttpHandler,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have "username" as required field', async(() => {
    fixture.whenStable().then(() => {
      let username = component.UserModel.username;
      expect(username!==undefined).toBeFalsy();
      username="nivetha";
      expect(username!==undefined).toBeTruthy();
    });
  }));

  it('should have "password" as required field', async(() => {
    fixture.whenStable().then(() => {
      let password = component.UserModel.password;
      expect(password!==undefined).toBeFalsy();
      password="password1234";
      expect(password!==undefined).toBeTruthy();
    });
  }));

  it("should be able to successfully login", async(() => {
    fixture.whenStable().then(() => {
      let username = component.UserModel.username;
      let password = component.UserModel.password;
      username="nivetha"
      password="password1234"
      component.onLogin();
    });
  }));

});
