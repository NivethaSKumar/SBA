import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { map } from "rxjs/operators";
import {AuthService} from '../interceptors/auth.service';

@Injectable({
  providedIn: 'root'
})
export class LoginService {


  constructor(private http:HttpClient,private authService:AuthService) { }

  public getAuthenticate():Observable<any>{
   const reportUrl='http://localhost:8051/info/authenticate'
    return this.http.get(reportUrl);

  }

  public getLogin(postData):Observable<any>{
   
    const reportUrl='http://localhost:8050/login/players/login'
        return this.http.post(reportUrl,postData).pipe(map(
          (data: any) => {
            console.log(data);
            return data;
          },
          (error: any) => {
            console.log(error);
            return error;
          }));
    
      }

    
}
