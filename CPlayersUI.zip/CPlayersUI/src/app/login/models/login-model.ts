export class UserModel {
    public username: string;
    public password: string;
    public email:string;
    
}
export class jwtRequest {
    public username: string;
    public password: string;
       
}
export class User {
    public user: string;
    public pwd: string;    
}