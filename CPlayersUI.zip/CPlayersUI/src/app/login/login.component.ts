import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import{UserModel,jwtRequest,User} from './models/login-model';
import {LoginService} from './login.service'
import {AuthService} from '../interceptors/auth.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public UserModel: UserModel;
  public User:User;
  public jwtRequest :jwtRequest;
  public token:string;
  submitMessage: String;
  constructor(private router:Router,private LoginService:LoginService,private authService:AuthService) { }

  ngOnInit() {
    this.UserModel = new UserModel();
    this.jwtRequest=new jwtRequest();
    this.User=new User();
    this.User.user=this.UserModel.username;
    this.User.pwd=this.UserModel.password;
    this.jwtRequest.username=this.UserModel.username;
    this.jwtRequest.password=this.UserModel.password;
  }
  public onClickSignUp(){
    this.router.navigate(['register']);
  }

  public onLogin(){
    if(this.UserModel.username === undefined || this.UserModel.password===undefined 
      || this.UserModel.username.length === 0 || this.UserModel.password.length === 0) {
      alert('Enter mandatory fields to continue');
      return;
    }
    const postData = {
      'username': (this.UserModel.username) ? this.UserModel.username : '',
      'password': (this.UserModel.password) ? this.UserModel.password : ''
    }
    this.jwtRequest.username=this.UserModel.username;
    this.jwtRequest.password=this.UserModel.password;
    console.log('username',this.UserModel.username);
    console.log('password',this.UserModel.password );
    this.authService.isUserAuthenticated(this.UserModel).subscribe(res => {
      if(res == true) {
        this.User.user=this.UserModel.username;
      this.User.pwd=this.UserModel.password;
      console.log('test user',this.User.user );
      console.log('test pwd',this.User.pwd);
          this.LoginService.getLogin(this.User).subscribe(res=>{
          if(res['response']==='Valid User. Login successful'){
          console.log("SUCCESS RESPONSE");
          localStorage.setItem('userName',postData.username);
          localStorage.setItem('password','password');
          this.router.navigate(['findplayer']);
          }else{
            alert("Invalid User");
          }
            } ), err=>{
              this.submitMessage="Login failed. Invalid User";
              if (err.message === 'Http failure response for http://localhost:8050/login/: 403 Forbidden') {
            this.submitMessage = 'Unauthorized';
          }
            }
      }else{
        this.router.navigate(['login']);
      }
    })
    
   
  }

  
}
