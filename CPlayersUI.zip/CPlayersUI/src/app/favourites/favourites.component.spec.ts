import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FavouritesComponent } from './favourites.component';
import { of } from "rxjs";
import { RouterTestingModule } from "@angular/router/testing";
import {AuthService} from '../interceptors/auth.service';
import { Router } from '@angular/router';
import { HttpClient,HttpHandler } from '@angular/common/http';
import { FormsModule } from '@angular/forms'; 
import{FavouritesService} from './favourites.service';
let mockFavouriteService={
  getFavPlayerDtls:()=>{
    return of (
      [{
      playerId:"11111",
      playersName:"M.S.Dhoni",
      country:"Dhoni"
      },
    {
      playerId:"22222",
      playersName:"Virat Kohli",
      country:"Virat"
    }]
    
    )
  }
}
let router = {
  navigate: jasmine.createSpy("navigate")
};
let mockAuthService={
  isUserAuthenticate:(userInfo)=>{
      return of (true)
  }
};

describe('FavouritesComponent', () => {
  let component: FavouritesComponent;
  let fixture: ComponentFixture<FavouritesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FavouritesComponent ],
      imports: [RouterTestingModule.withRoutes([]), FormsModule],
      providers: [
        { provide: AuthService, useValue: mockAuthService },
        { provide: FavouritesService, useValue: mockFavouriteService },
        { provide: Router, useValue: router },
        HttpClient,
        HttpHandler,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FavouritesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("should be able to fetch Favourite Player Details", async(() => {
    fixture.whenStable().then(() => {
      let playerId = component.favouriteList.playerId;
      let playername=component.favouriteList.playername;
      let country=component.favouriteList.country;
      playerId="11121";
      playername="Sachin Rana";
      country="Sachin Rana";
		 component.ngOnInit();
    });
  }));
});
