import { Component, OnInit } from '@angular/core';
import{FavouritesService} from './favourites.service';
import {AuthService} from '../interceptors/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-books',
  templateUrl: './favourites.component.html',
  styleUrls: ['./favourites.component.css']
})
export class FavouritesComponent implements OnInit {
public favouriteList:any=[];
constructor(private favService:FavouritesService,private authService:AuthService,private router:Router){}

  ngOnInit() {
    const postData={
      'username': localStorage.getItem('userName') ? localStorage.getItem('userName') : '',
      'password': localStorage.getItem('password') ? localStorage.getItem('password') : ''
    }
    this.authService.isUserAuthenticate(postData).subscribe(res => {
      if(res == true) {
    this.favService.getFavPlayerDtls().subscribe(data=>{
      if(data && data.length>0){
    console.log('FavPlayerDetails',data);
    this.favouriteList=data; 
    console.log('list',this.favouriteList);
      }
      else{
        alert('No Favourite Player list available for logged in user!!!')
      }
    }, err=>{
     
        this.router.navigate(['login']);

    })
  }
})

    }

    public logout(){
      localStorage.clear;
      this.authService.setBearerToken('')
      this.router.navigate(['login']);
    }
    
  }

  
