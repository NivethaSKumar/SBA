import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import { map } from "rxjs/operators";
import {AuthService} from '../interceptors/auth.service';

@Injectable({
  providedIn: 'root'
})
export class FavouritesService {
 constructor(private http:HttpClient,private authService:AuthService){}
 getFavPlayerDtls() {
    return this.http.get<any>('http://localhost:8051/info/players/fav-players' +'/'+ localStorage.getItem('userName')
    ).pipe(map(
      (data: any) => {
        console.log(data);
        return data;
      },
      (error: any) => {
        console.log('*** ',error);
        return error;
      }));
  }
}

  
