export class UserModel {
    public userName: string;
    public password: string;
}
export class playerModel{
    public playername: string;
    constructor(){
        this.playername='';
    }
}