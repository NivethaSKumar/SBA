import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import{RegisterComponent} from './register/register.component';
import{FindPlayerComponent} from './findplayer/findplayer.component';
import {StatisticsComponent} from './statistics/statistics.component';
import{FavouritesComponent} from './favourites/favourites.component';

const routes: Routes = [
  {path: "", component: LoginComponent},
  {path: "login", component: LoginComponent},
  {path: "register", component: RegisterComponent},
  {path: "findplayer", component: FindPlayerComponent},
  {path: "statistics", component: StatisticsComponent},
  {path: "favourites",component: FavouritesComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
