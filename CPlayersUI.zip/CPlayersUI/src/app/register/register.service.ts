import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import {AuthService} from '../interceptors/auth.service';
import { map } from "rxjs/operators";



@Injectable({
  providedIn: 'root'
})
export class RegisterService {


  constructor(private http:HttpClient,private authService: AuthService) {

   }

  public getAuthenticate():Observable<any>{
    const reportUrl='http://localhost:8051/info/authenticate'
     return this.http.get(reportUrl);
 
   }

  public getRegister(postData):Observable<any>{
     const reportUrl='http://localhost:8050/login/players/register';
        return this.http.post(reportUrl,postData
        ).pipe(map(
          (data: any) => {
            console.log(data);
            return data;
          },
          (error: any) => {
            console.log(error);
            return error;
          }));;
    
      }
}
