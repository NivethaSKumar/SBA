import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterComponent } from './register.component';
import { of } from "rxjs";
import { RouterTestingModule } from "@angular/router/testing";
import { Router } from '@angular/router';
import {RegisterService} from './register.service';
import { HttpClient,HttpHandler } from '@angular/common/http';
import { FormsModule } from '@angular/forms'; 
let mockRegisterService={
  getRegister:(data)=>{
    return of ('Db saved successfully')
  }
}
let router = {
  navigate: jasmine.createSpy("navigate")
};
describe('RegisterComponent', () => {
  let component: RegisterComponent;
  let fixture: ComponentFixture<RegisterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisterComponent ],
      imports: [RouterTestingModule.withRoutes([]), FormsModule,],
      providers: [
        { provide: RegisterService, useValue: mockRegisterService },
        { provide: Router, useValue: router },
        HttpClient,
        HttpHandler,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have "username" field', async(() => {
    fixture.whenStable().then(() => {
      let username = component.UserModel.userName;
      expect(username!==undefined).toBeFalsy();
      username="nivetha";
      expect(username!==undefined).toBeTruthy();
    });
  }))

  it('should have "password" field', async(() => {
    fixture.whenStable().then(() => {
      let password = component.UserModel.password;
      expect(password!==undefined).toBeFalsy();
      password="password1234";
      expect(password!==undefined).toBeTruthy();
    });
  }));

  it('should have "confirmPassword" field', async(() => {
    fixture.whenStable().then(() => {
      let confpassword = component.UserModel.confirmpassword;
      expect(confpassword!==undefined).toBeFalsy();
      confpassword="password1234";
      expect(confpassword!==undefined).toBeTruthy();
    });
  }));

  it('should have "email" field', async(() => {
    fixture.whenStable().then(() => {
      let email = component.UserModel.email;
      expect(email!==undefined).toBeFalsy();
      email="nive@gmail.com";
      expect(email!==undefined).toBeTruthy();
    });
  }));

  it("should be able to successfully register", async(() => {
    fixture.whenStable().then(() => {
      let username = component.UserModel.userName;
      let password = component.UserModel.password;
      let confirmpassword=component.UserModel.confirmpassword;
      let email=component.UserModel.email;
      username="nivetha";
      password="password1234";
      confirmpassword="password1234";
      email="nive@gmail.com";
      component.onRegister();
    });
  }));
});
