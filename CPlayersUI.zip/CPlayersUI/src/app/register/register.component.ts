import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import{UserModel,jwtRequest} from './model/register-model';
import { Router } from '@angular/router';
import {RegisterService} from './register.service';
import {AuthService} from '../interceptors/auth.service';
import {LoginService} from '../login/login.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  loginForm: FormGroup;

  public UserModel: UserModel;
  public jwtRequest:jwtRequest;
  public token:string;
  constructor(private router:Router,private RegisterService:RegisterService) { }

  ngOnInit() {
    this.UserModel = new UserModel();
  }

  public onRegister(){

    if(this.UserModel.userName ===undefined || this.UserModel.userName.length===0||this.UserModel.password===undefined||
      this.UserModel.password.length===0||this.UserModel.confirmpassword===undefined||this.UserModel.confirmpassword.length===0||
      this.UserModel.email===undefined||this.UserModel.email.length===0){
        alert('Please enter all the fields');
        return;
      }
      if(this.UserModel.password !== this.UserModel.confirmpassword) {
        alert('Password & confirm password doesnt match. Please enter correctly')
      }

      if(this.UserModel.userName !==undefined && this.UserModel.userName.length!==0 &&
        this.UserModel.password!==undefined &&
        this.UserModel.password.length!==0 && this.UserModel.confirmpassword!==undefined && 
        this.UserModel.confirmpassword.length!==0 &&
        this.UserModel.email!==undefined && this.UserModel.email.length!==0 
        && this.UserModel.password===this.UserModel.confirmpassword){
         
    const postData = {
      'user': (this.UserModel.userName) ? this.UserModel.userName : '',
      'pwd': (this.UserModel.password) ? this.UserModel.password : '',
      'email': (this.UserModel.email) ? this.UserModel.email : ''
    }
    console.log('username',this.UserModel.userName);
    console.log('password',this.UserModel.password );
    console.log('email',this.UserModel.email);
    console.log('cpassword',this.UserModel.confirmpassword);

    this.RegisterService.getRegister(postData).subscribe(res => {
      if(res['response']==='Db saved successfully') {
        let token='Db saved successfully';
        this.router.navigate(['login']);
       // alert('You are successfully registered into the system');
      }else {
        this.router.navigate(['register']);
        alert('Please try after some time');
      }
    
    })
  }
  }
    
     
  }


