export class booksModel {
    public bookname: string[];
    public authorname: number[];
    public genre: string[];
}
export class UserModel {
    public userName: string;
    public password: string;
    public email:string;
    public confirmpassword:string;
    
}

export class jwtRequest {
    public username: string;
    public password: string;
    constructor(){
        this.username='';
        this.password='';
    }   
}