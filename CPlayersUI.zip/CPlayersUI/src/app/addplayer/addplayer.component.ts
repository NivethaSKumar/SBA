// import { Component, OnInit } from '@angular/core';
// import{AddPlayerService} from './addplayer.service';
// import {AuthService} from '../interceptors/auth.service';
// import { Router } from '@angular/router';
// import {playerModel} from './model/addplayer.model';

// @Component({
//   selector: 'app-books',
//   templateUrl: './addplayer.component.html',
//   styleUrls: ['./addplayer.component.css']
// })
// export class AddPlayerComponent implements OnInit {
//   public playerModel: playerModel;
//   public isAdd:boolean;
//   constructor(private router:Router,private playerService:AddPlayerService,private authService:AuthService) { }
//   ngOnInit() {
//     this.isAdd=true;
//     this.playerModel=new playerModel();
//     const postData={
//       'username': localStorage.getItem('userName') ? localStorage.getItem('userName') : '',
//       'password': localStorage.getItem('password') ? localStorage.getItem('password') : ''
//     }
//     this.authService.isUserAuthenticate(postData).subscribe(res => {
//       if(res == true) {
//       }
//     })
//     }

//     public addPlayer(){
//       if(this.playerModel.playerId===undefined || this.playerModel.playersName===undefined || this.playerModel.country===undefined 
//         || this.playerModel.playerId.length===0 || this.playerModel.playersName.length === 0 || this.playerModel.country.length===0 ) {
//         alert('Enter mandatory fields to ADD PLAYERS');
//         return;
//       }
//       const postData = {
//         'playerId': (this.playerModel.playerId) ? this.playerModel.playerId : '',
//         'playersName': (this.playerModel.playersName) ?  this.playerModel.playersName : '',
//         'country': (this.playerModel.country) ? this.playerModel.country : ''
//       }
//       console.log('playerId',this.playerModel.playerId);
//       console.log('playersName',this.playerModel.playersName);
//       console.log('country',this.playerModel.country);
//       this.playerService.addFavPlayer(postData).subscribe(res => {
//         if(res['response']==='Favourite Player Details added to your system') {
          
//           alert('Favourite Player Details added to your system');
//         }else {
//           this.router.navigate(['addplayer']);
//           alert('Favourite Player Details could not be added to the system! Try adding again');
//         }
//       })
//       this.isAdd=false;
//     }

//     public removePlayer(){
//       if(this.playerModel.playerId===undefined || this.playerModel.playersName===undefined || this.playerModel.country===undefined 
//         || this.playerModel.playerId.length===0 || this.playerModel.playersName.length === 0 || this.playerModel.country.length===0 ) {
//         alert('Enter mandatory fields to REMOVE PLAYERS');
//         return;
//       }
//       const postData = {
//         'playerId': (this.playerModel.playerId) ? this.playerModel.playerId : '',
//         'playersName': (this.playerModel.playersName) ?  this.playerModel.playersName : '',
//         'country': (this.playerModel.country) ? this.playerModel.country : ''
//       }
//       console.log('playerId',this.playerModel.playerId);
//       console.log('playersName',this.playerModel.playersName);
//       console.log('country',this.playerModel.country);
//       this.playerService.removeFavPlayer(postData).subscribe(res => {
//         if(res['response']==='Favourite Player details removed from the system') {
          
//           alert('Favourite Player details removed from the system');
//         }else {
//           this.router.navigate(['addplayer']);
//           alert('Favourite Player Details could not be removed from the system! Try removing again');
//         }
//         this.playerModel.playerId='';
//         this.playerModel.playersName='';
//         this.playerModel.country='';


//       })
//       this.isAdd=true;
//     }
    
//     public logout(){
//       localStorage.clear;
//       this.authService.setBearerToken('');
//       this.router.navigate(['login']);
//     }
    
//   }

  
