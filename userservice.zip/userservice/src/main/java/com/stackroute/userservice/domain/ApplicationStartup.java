
package com.stackroute.userservice.domain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component

public class ApplicationStartup

		implements ApplicationListener<ApplicationReadyEvent> {

	Logger logger = LoggerFactory.getLogger(ApplicationStartup.class);

	private Connection getConnection() throws SQLException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) { // TODO Auto-generatecatch block
			e.printStackTrace();
		}
//		Connection con = DriverManager.getConnection("jdbc:mysql://mysql:3306/sys?autoReconnect=true&useSSL=false",
//				"root", "root");
		Connection con = DriverManager.getConnection("jdbc:mysql://mysql:3306/sys",
				"root", "root");
		return con;
	}

	public void createddlScripts() {
		Connection conn = null;
		Statement ps = null;
		try {
			conn = getConnection();

			ps = conn.createStatement();
			logger.info(">>>>>>>>>>>>>>>>>>>>>>>> Connection created successfully. executing DDLs");

			int result = ps.executeUpdate(
					"create table usersdtls(userid int(50) not null auto_increment,primary key(userid), username varchar(100),\n"
							+ "emailaddress varchar(200),password varchar(100))");
			logger.info(">>>>>>>>>>>>>>>>>>>>>>>> 1.  executing DDLs" + result);
			result = ps.executeUpdate("create table favouriteplayers(id int(50), playerid varchar(50),playerfullname varchar(500),playername varchar(300))");
			logger.info(">>>>>>>>>>>>>>>>>>>>>>>> 2.  executing DDLs" + result);
			result = ps.executeUpdate("insert into usersdtls (userid,username,emailaddress,password)\n"
					+ "VALUES(null,'Admins','admin@gmail.com','pwd')");
			logger.info(">>>>>>>>>>>>>>>>>>>>>>>> 3.  executing DDLs" + result);			
			result=ps.executeUpdate("insert into favouriteplayers (id,playerid,playerfullname,playername) values\n" + 
					" (1,'33757','Sachin Rana','Sachin Rana')");
			logger.info(">>>>>>>>>>>>>>>>>>>>>>>> 4.  executing DDLs" + result);
			ps.close();
		} catch (SQLException e) { // TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				// TODOAuto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override

	public void onApplicationEvent(final ApplicationReadyEvent event) {
		logger.info(">>>>>>>>>>>>>>>>>>>>>>>> Before createdddlscript call");
		try {
			Thread.sleep(30000);
		} catch (InterruptedException e) {
			// TODOAuto-generated catch block
			e.printStackTrace();
		}
		createddlScripts();
		logger.info(">>>>>>>>>>>>>>>>>>>>>>>> After createdddlscript call");

		return;

	}

}
