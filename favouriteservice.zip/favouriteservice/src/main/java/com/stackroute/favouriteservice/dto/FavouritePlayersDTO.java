package com.stackroute.favouriteservice.dto;

public class FavouritePlayersDTO {
	
	private String playerId;
	
	private String playersName;
	
	private String country;

	public String getPlayerId() {
		return playerId;
	}

	public void setPlayerId(String playerId) {
		this.playerId = playerId;
	}

	public String getPlayersName() {
		return playersName;
	}

	public void setPlayersName(String playersName) {
		this.playersName = playersName;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	

}
